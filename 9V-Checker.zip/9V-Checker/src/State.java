import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class State {
    private String name;
    Map<String, String> total;
    List<String> actions;


    public State(String name) {
        this.name = name;
        total = new HashMap<String, String>();
        actions = new ArrayList<String>();
    }

    public void addAction(String act) {
        actions.add(act);
    }

    public State() {
        this.name = "";
        total = new HashMap<String, String>();
    }

    public void setName(String n) {
        name = n;
    }

    public String getName() {
        return name;
    }

    public void addValue(String var, String val) {
        if (var != "" && val != "") {
            total.put(var, val);
        }
    }

}
