import java.util.HashMap;
import java.util.Map;

public class Transition {
	
	private String source;//
	private String destination;//
	private String localAction;//
	// in same order as variables array
	//private Map<String,String> localVariableValues;
	private Map<String,String> goalLocalVariableValues;//
	// in same order as external agents
	
	private Map<String,String> externalActions;//
	// are there external variables values ?? NO
	
	
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getLocalAction() {
		return localAction;
	}
	public void setLocalAction(String localAction) {
		this.localAction = localAction;
	}
	/*public Map<String, String> getLocalVariableValues() {
		return localVariableValues;
	}
	public void setLocalVariableValues(Map<String, String> localVariableValues) {
		this.localVariableValues = localVariableValues;
	}*/
	public Map<String, String> getGoalLocalVariableValues() {
		return goalLocalVariableValues;
	}
	public void setGoalLocalVariableValues(Map<String, String> goalLocalVariableValues) {
		this.goalLocalVariableValues = goalLocalVariableValues;
	}
	public Map<String, String> getExternalActions() {
		return externalActions;
	}
	public void setExternalActions(Map<String, String> externalActions) {
		this.externalActions = externalActions;
	}
	
	
	public Transition() 
	{
		externalActions = new HashMap<String, String>();
		goalLocalVariableValues = new HashMap<String, String>();
		
	}
	public void addExternalAction (String agent, String action)
	{
		externalActions.put(agent, action);
	}
	public void addgoalLocalVariableValues (String var, String val)
	{
		goalLocalVariableValues.put(var, val);
	}
	/*public void addlocalVariableValues (String var, String val)
	{
		localVariableValues.put(var, val);
	}*/
	@Override
	public String toString() {
		return "Transition [source=" + source + ", destination=" + destination + ", localAction=" + localAction
				+ ", goalLocalVariableValues=" + goalLocalVariableValues + ", externalActions=" + externalActions + "]";
	}
	
	
	
	
	
	
	

}
