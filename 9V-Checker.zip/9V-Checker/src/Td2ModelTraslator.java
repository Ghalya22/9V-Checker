
 
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.text.JTextComponent;

import javax.swing.*;
import java.awt.*;

public class Td2ModelTraslator<pubilc> {	          
    static <D> File transfyFile2(File fFile, String oldString1,String oldString2, String oldString3,String newString1,String oldString4,String oldString5,String oldString6,String oldString7,String oldString8,String newString2,String newString3)
    {       
		File fileToBeModified =   fFile;
                
        String oldContent = "";
         
        BufferedReader reader = null;
         
        //FileWriter writer = null;
         
        try
        {
            reader = new BufferedReader(new FileReader(fileToBeModified));
             
          //Reading all the lines of input text file into oldContent
            
            String line = reader.readLine();
             
            while (line != null) 
            {
                oldContent = oldContent + line + System.lineSeparator();
                 
                line = reader.readLine();
            }
             
            //Replacing oldString with newString in the oldContent
             
            String newContent = oldContent.replaceAll(oldString1, newString1); 
         //   System.out.println(newContent);
            String newContent1 = newContent.replaceAll(oldString1, newString1);
            String newContent2 = newContent1.replaceAll(oldString2, newString1);
            String newContent3 = newContent2.replaceAll(oldString3, newString1);
            String newContent4 = newContent3.replaceAll(oldString4, newString3);
            String newContent5 = newContent4.replaceAll(oldString5, newString3);
            String newContent6 = newContent5.replaceAll(oldString6, newString2);
            String newContent7 = newContent6.replaceAll(oldString7, newString2);
            String newContent8 = newContent7.replaceAll(oldString8, newString1);

            //System.out.println("done");
           // System.out.println(newContent2);
           new TextAreaCTLC_Translated(newContent8);
            
             
           
           
        //  FileWriter writer1 =new FileWriter("c:/Tmodel.txt");
            
       //    writer1.write(newContent);
          //  writer1.close();          
            System.out.println("done");
            
            // new TextAreaDemo(newConten);
            ////////////////////////////////////
                            	                          
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                //Closing the resources
                 
                reader.close();
                 
               // writer.close();
            } 
            catch (IOException e) 
            {
                e.printStackTrace();
            }
        }
		return fileToBeModified;
    }

	public static void main(String[] args)  
    {
		 
             
    }
	
} 
	
	


 

 
