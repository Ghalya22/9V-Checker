import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.metal.DefaultMetalTheme;
import javax.swing.plaf.metal.MetalLookAndFeel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.DecimalFormat;
import java.awt.Color;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
public class MainFrame extends javax.swing.JFrame {
    private final TextArea txt;
    private final JPanel content;
    
    private final JButton generateTButton; 
    private final JButton generate_Td_1_Button;
    private final JButton generate_Td_2_Button;
   // private final JButton generate_u_Button;
    private final JButton generate_Fd_1_Button;
    private final JButton generate_Fd_2_Button;
    private final JButton generate_Fd1_and_Fd2_Button;    
    private final JButton loadFileButton2;
    private final JLabel backgroundLabel;
  
    private File inputFile1;
    private File inputFile2;
  
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                MainFrame form = new MainFrame();
                form.setVisible(true);
                
            }
        });
    }
    @SuppressWarnings({ "rawtypes", "removal" })
	public MainFrame() {
    	
    		
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	Color lab1 =new Color(81, 85, 110);
    	Color lab2 =new Color(192, 192, 192);
    	 
    	
    	Color lab4 =new Color(81, 100, 110);
    	setTitle("9V-TCTL Model Checker");    		 
        setSize(1000, 1100);
        setLocation(300, 40);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        //mainFramColor
        Color col =new Color(176, 196, 222);
        getContentPane().setBackground(col);
        content = (JPanel) this.getContentPane();         
        txt = new TextArea();
        txt.setBounds(12, 280, 700,580);
        txt.setMaximumSize(new Dimension(600, 580));
        txt.setPreferredSize(new Dimension(600, 580));
        txt.setMaximumSize(new Dimension(800, 980));
        txt.setEditable(false);
        content.add(txt);
        
        
        loadFileButton2 = new JButton("Upload 9V-TCTL model");
        loadFileButton2.setBounds(340, 40, 180, 30);
        col =new Color(255,255, 255);
        loadFileButton2.setBackground(col);
        loadFileButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                JFileChooser choose = new JFileChooser();
                choose.setDialogTitle("Load ISPL File");
                int returnVal = choose.showOpenDialog(new JFrame());
                if (returnVal == JFileChooser.APPROVE_OPTION) {

                    File expectedFile = choose.getSelectedFile();
                    inputFile2 = expectedFile;
                    String fileContent2 = loadISPLFile4v(expectedFile);
                    if (expectedFile != null) inputFile2 = expectedFile;
                    txt.setText(fileContent2);
                }
            }
        });
        
        getContentPane().add(loadFileButton2);
///////////////////////////////////////////////////////
generateTButton= new JButton("Generate T model");     
generateTButton.setBounds(70, 110, 180, 30);
content.add(generateTButton);
generateTButton.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
if (inputFile2 == null || txt.getText().length()==0){
throwErrorDialogue("Please Load a 9V-Model before Trying to Generate a TCTL Model.","Illegal Action");
}
else{
//TModelTraslator.transfyFile2(inputFile2, "=Td1_or_Td2 if","=Td1_and_Td2 if","=Td2 if","=Td1 if", "if !","=T","");
  TModelTraslator.transfyFile2(inputFile2,"=Td1 if", "=Td1_j_Td2 if","=Fd1_m_Fd2 if","=Fd1 if","=Fd2 if","=u if","if !","=Td2 if","");

}
}     
});
getContentPane().add(generateTButton);


generate_Td_1_Button= new JButton("Generate Td1 model");     
generate_Td_1_Button.setBounds(70, 200, 180, 30);
content.add(generate_Td_1_Button);
generate_Td_1_Button.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
if (inputFile2 == null || txt.getText().length()==0){
throwErrorDialogue("Please load a 6V-Model before trying to generate an TCTL model.","Illegal Action");
}
else{
//Td1ModelTraslator.transfyFile2(inputFile2,"=T ","=Td1_or_Td2","=Td1"," ","=Td2 if","=u if","=Fd1 if","=Fd2 if","=Fd1_and_Fd2 if","if !");
  Td1ModelTraslator.transfyFile2(inputFile2,"=T ","=Td1_j_Td2","=Td1"," ","=Td2 if","=u if","=Fd1 if","=Fd2 if","=Fd1_m_Fd2 if","!","if !");
}
}     
});
getContentPane().add(generate_Td_1_Button);
	

backgroundLabel = new JLabel();
backgroundLabel.setBounds(-10, 5, 1500, 830); 
//backgroundLabel.setBounds(0, 5, 1500, 590);
backgroundLabel.setIcon(new ImageIcon("Image/imag1.jpg"));  
content.add(backgroundLabel, new Integer(Integer.MIN_VALUE));  


generate_Td_2_Button= new JButton("Generate T_d2 model");     
generate_Td_2_Button.setBounds(340, 200, 180, 30);
content.add(generate_Td_2_Button);
generate_Td_2_Button.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
if (inputFile2 == null || txt.getText().length()==0){
throwErrorDialogue("Please load a 6V-Model before trying to generate a TCTL model.","Illegal Action");
}
else{
//Td2ModelTraslator.transfyFile2(inputFile2,"=T ","=Td1_or_Td2","=Td2"," ","=Td1 if","=u if","=Fd1 if","=Fd2 if","=Fd1_and_Fd2 if","if !");
  Td2ModelTraslator.transfyFile2(inputFile2,"=T ","=Td1_j_Td2","=Td2 if"," ","=Td1 if","=u if","=Fd1 if","=Fd1 if","=Fd1_m_Fd2 if","!"," if !");

}
}     
});
getContentPane().add(generate_Td_2_Button);

 

generate_Fd_1_Button= new JButton("Generate ⊥_d1 model");     
generate_Fd_1_Button.setBounds(600, 110, 180, 30);
content.add(generate_Fd_1_Button);
generate_Fd_1_Button.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
if (inputFile2 == null || txt.getText().length()==0){
throwErrorDialogue("Please load a 6V-Model before trying to generate an TCTL model.","Illegal Action");
}
else{
//Fd1ModelTraslator.transfyFile2(inputFile2,"=T","=Td1_or_Td2 if","=Td2","Td1","u","Fd1","","Fd2","Fd1_and_Fd2 if","if !");
  Fd1ModelTraslator.transfyFile2(inputFile2,"=T ","=Td1_j_Td2 ","=Td2 if ","=Td1","=u","=Fd1"," ","=Fd2","=Fd1_m_Fd2 if","if !","!");

}
}     
});
getContentPane().add(generate_Fd_1_Button);

generate_Fd_2_Button= new JButton("Generate ⊥_d2 model");     
generate_Fd_2_Button.setBounds(600, 200, 180, 30);
content.add(generate_Fd_1_Button);
generate_Fd_2_Button.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
if (inputFile2 == null || txt.getText().length()==0){
throwErrorDialogue("Please load a 6V-Model before trying to generate an TCTL model.","Illegal Action");
}
else{
//Fd2ModelTraslator.transfyFile2(inputFile2,"=T","=Td1_or_Td2 if","=Td2","Td1","u","Fd2","","Fd1","Fd1_and_Fd2 if","if !");
 Fd1ModelTraslator.transfyFile2(inputFile2,"=T ","=Td1_j_Td2 ","=Td2 if ","=Td1","=u","=Fd1"," ","=Fd2","=Fd1_m_Fd2 if","if !","!");

}
}     
});
getContentPane().add(generate_Fd_2_Button);


generate_Fd1_and_Fd2_Button= new JButton("Generate ⊥d1 ⊓ ⊥d2 model");     
generate_Fd1_and_Fd2_Button.setBounds(340, 110, 180, 30);
content.add(generate_Fd1_and_Fd2_Button);
generate_Fd1_and_Fd2_Button.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent e) {
if (inputFile2 == null || txt.getText().length()==0){
throwErrorDialogue("Please load a 6V-Model before trying to generate an TCTL model.","Illegal Action");
}
else{
//Fd1ANDFd2ModelTraslator.transfyFile2(inputFile2,"=T","=Td1_or_Td2 if","=Td2","Td1","u","Fd2","Fd1","Fd1_and_Fd2 if","");
 Fd1ANDFd2ModelTraslator.transfyFile2(inputFile2,"=T ","=Td1_j_Td2 ","=Td2 if ","=Td1 ","=u ","=Fd2","=Fd1 ","=Fd1_m_Fd2 if"," ","if !");

} 
}
});
getContentPane().add(generate_Fd1_and_Fd2_Button);
	

    }	


    private String loadISPLFile(File f) {
        StringBuilder b = new StringBuilder("");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(f));
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.contains("--")) {
                    b.append(line.split("--")[0]);
                } else {
                    b.append(line + "\n");  
            }
            }
        } catch (FileNotFoundException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File Not Found");

        } catch (IOException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File System Access Permission");
        }
        return b.toString();
    }
    
    private String loadISPLFile3v(File s) {
        StringBuilder b = new StringBuilder("");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(s));
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.contains("--")) {
                    b.append(line.split("--")[0]);
                } else {
                    b.append(line + "\n");
                }
             
               
            }
        } catch (FileNotFoundException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File Not Found");

        } catch (IOException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File System Access Permission");
        }
        return b.toString();
    }
    private String loadISPLFile4v(File w) {
        StringBuilder b = new StringBuilder("");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(w));
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.contains("--")) {
                    b.append(line.split("--")[0]);
                } else {
                    b.append(line + "\n");
                }
              
                
               
            }
        } catch (FileNotFoundException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File Not Found");

        } catch (IOException e) {

            throwErrorDialogue("Unable to read from the ISPL Input File !", "File System Access Permission");
        }
        return b.toString();
    }
    
    private static void throwErrorDialogue(String errorMessage, String typeOfError) {
        JOptionPane.showMessageDialog(new JFrame(), errorMessage, typeOfError, JOptionPane.ERROR_MESSAGE);
    }


    @SuppressWarnings("serial")
    static class mcmas extends JFrame implements ActionListener {
    	 
    	
    	
        static String modelOutput = "";
        static String modelFileSaved = "C:\\JTL\\scal.out";

        long formulae, starts, ends;
        double mo, fo;
        static double[] formulaTable;

        @SuppressWarnings("static-access")
        public mcmas(String h, double m, double f, double[] formulaTimeTable) {
            this.setName("mcmas Launch Interface");
            initComponents();
            jTextArea1.setText(h);
            mo = m;
            fo = f;
            if (formulaTimeTable != null) {
                this.formulaTable = formulaTimeTable;
                formulae = 0;
                for (int i = 0; i < formulaTimeTable.length; ++i) {
                    formulae += formulaTimeTable[i];
                }
            }

        }


        private void initComponents() {

            jPanel1 = new JPanel();           
            jScrollPane1 = new JScrollPane();
            jTextArea1 = new JTextArea();
            launchmcmasButton = new JButton();
            jPanel2 = new JPanel();
            jScrollPane2 = new JScrollPane();
            jTextArea2 = new JTextArea();
            jLabel1 = new JLabel();
            jTextField1 = new JTextField();
            jLabel2 = new JLabel();
            jTextField2 = new JTextField();
            jLabel3 = new JLabel();
            jTextField3 = new JTextField();
            jTextField4 = new JTextField();
            jLabel4 = new JLabel();
            timeFormulaButton = new JButton();

            setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

            jScrollPane1.setBorder(BorderFactory.createTitledBorder("CTL Model"));              
            jTextArea1.setColumns(20);
            jTextArea1.setRows(5);
            jTextArea1.setBorder(BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
            jScrollPane1.setViewportView(jTextArea1);
            jTextArea1.getAccessibleContext().setAccessibleName("");

            launchmcmasButton.setText("Launch mcmas");

            jPanel2.setBorder(BorderFactory.createTitledBorder("Verification Results"));

            jTextArea2.setColumns(20);
            jTextArea2.setRows(5);
            jScrollPane2.setViewportView(jTextArea2);

            GroupLayout jPanel2Layout = new GroupLayout(jPanel2);
            jPanel2.setLayout(jPanel2Layout);
            jPanel2Layout.setHorizontalGroup(
                    jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jScrollPane2)
                                    .addContainerGap())
            );
            jPanel2Layout.setVerticalGroup(
                    jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jScrollPane2, GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE)
                                    .addContainerGap())
            );

            jLabel1.setText("Time of Transofrming Model");

            jTextField1.setText("0ms");

            jLabel2.setText("Total Time of Transforming Formulas");

            jTextField2.setText("0ms");

            jLabel3.setText("Time of Verification Process");

            jTextField3.setText("0ms");

            jTextField4.setText("0ms");

            jLabel4.setText("Total Time");

            timeFormulaButton.setForeground(new Color(0, 102, 255));
            timeFormulaButton.setText("Time/Formula");
            timeFormulaButton.setBorder(null);

            GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
                   
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                    jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 490, GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(launchmcmasButton)
                                                    .addGap(0, 0, Short.MAX_VALUE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jPanel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addContainerGap())
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                                                            .addGroup(GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                                    .addComponent(jLabel4)
                                                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                    .addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, 186, GroupLayout.PREFERRED_SIZE))
                                                            .addGroup(GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                                            .addComponent(jLabel1)
                                                                            .addComponent(jLabel3)
                                                                            .addComponent(jLabel2))
                                                                    .addGap(25, 25, 25)
                                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                                            .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
                                                                            .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
                                                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                    .addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
                                                                                    .addGap(18, 18, 18)
                                                                                    .addComponent(timeFormulaButton)))))
                                                    .addGap(49, 49, Short.MAX_VALUE))))
            );
            jPanel1Layout.setVerticalGroup(
                    jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(launchmcmasButton)
                                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                    .addGap(18, 18, 18)
                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                            .addComponent(jLabel1)
                                                            .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                    .addGap(9, 9, 9)
                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                            .addComponent(jLabel2)
                                                            .addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(timeFormulaButton))
                                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                            .addComponent(jLabel3)
                                                            .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                                    .addGap(18, 18, Short.MAX_VALUE)
                                                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                            .addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(jLabel4)))
                                            .addComponent(jScrollPane1))
                                    .addContainerGap())
            );

            GroupLayout layout = new GroupLayout(getContentPane());
            getContentPane().setLayout(layout);
            layout.setHorizontalGroup(
                    layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addContainerGap())
            );
            layout.setVerticalGroup(
                    layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addContainerGap())
            );

            jPanel1.getAccessibleContext().setAccessibleName("CTL Model");
            launchmcmasButton.addActionListener(this);
            timeFormulaButton.addActionListener(this);
            pack();
        }// </editor-fold>

        private void runScalableModel() {
            // save file to run with mcmas
            saveGeneratedFile();
            starts = System.nanoTime();
            try {
                modelOutput = mcmasInteractor.runmcmasModel();
            } catch (IOException e) {
                JOptionPane
                        .showMessageDialog(
                                new JFrame(),
                                "The tool couldn't access files on the system, Please verify its running with admin privileges",
                                "File System Access Denied", JOptionPane.ERROR_MESSAGE);
            } finally {
                ends = System.nanoTime();
            }
            DecimalFormat formatter = new DecimalFormat("#00.000000");
            double process = (ends - starts) / (double) (cst);
            jTextField1.setText("" + formatter.format(mo) + "ms");
            jTextField2.setText("" + formatter.format(fo) + "ms");
            jTextField3.setText("" + formatter.format(process) + "ms");
            jTextField4.setText("" + formatter.format(mo + fo + process) + "ms");
            jTextArea2.setText(modelOutput);
        }

        private JButton launchmcmasButton;
        private JButton timeFormulaButton;
        private JLabel jLabel1;
        private JLabel jLabel2;
        private JLabel jLabel3;
        private JLabel jLabel4;
        private JPanel jPanel1;
        private JPanel jPanel2;
        private JScrollPane jScrollPane1;
        private JScrollPane jScrollPane2;
        private JTextArea jTextArea1;
        private JTextArea jTextArea2;
        private JTextField jTextField1;
        private JTextField jTextField2;
        private JTextField jTextField3;
        private JTextField jTextField4;
        static double cst = 10000000;
        public void saveGeneratedFile() {
            File file = new File(modelFileSaved);
            Writer output = null;
            try {
                output = new BufferedWriter(new FileWriter(file));
                output.write(jTextArea1.getText());
                output.close();
            } catch (IOException e) {
                //e.printStackTrace();
                JOptionPane
                        .showMessageDialog(
                                new JFrame(),
                                "The tool couldn't access files on the system, Please verify its running with admin priveleges",
                                "File System Access Denied", JOptionPane.ERROR_MESSAGE);
            }
        }


        @Override
        public void actionPerformed(ActionEvent arg0) {

            if (arg0.getSource() == launchmcmasButton) {
                runScalableModel();
            } else if (arg0.getSource() == timeFormulaButton) {
                JComponent[] input = new JComponent[2 * formulaTable.length];
                for (int i = 0; i < formulaTable.length; ++i) {
                    JLabel lab = new JLabel("Formula " + (i + 1));
                    JLabel labs = new JLabel(formulaTable[i] + "ms");
                    input[2 * i] = lab;
                    input[2 * i + 1] = labs;
                }
                @SuppressWarnings("unused")
                int result = JOptionPane.showConfirmDialog(null, input, "Time/Formula", JOptionPane.PLAIN_MESSAGE);
            }

        }
    }
     
}

class changeTheme extends DefaultMetalTheme {
Color	col =new Color(0,87, 157);
    public ColorUIResource getWindowTitleInactiveBackground() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getWindowTitleBackground() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getPrimaryControlHighlight() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getPrimaryControlDarkShadow() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getPrimaryControl() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getControlHighlight() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getControlDarkShadow() {
      return new ColorUIResource(col);
    }
  
    public ColorUIResource getControl() {
      return new ColorUIResource(col);
    }
}
