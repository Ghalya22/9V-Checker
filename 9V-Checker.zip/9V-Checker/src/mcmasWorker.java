import javax.swing.*;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.concurrent.ExecutionException;

public class mcmasWorker extends SwingWorker<String, String> {


    static String modelOutput = "";
    static String nusmvCommands = "mcmas";
    static String nusmvParameters = "-v 3 ";
    static String modelFileSaved = "C:\\JTL\\scal.out";
    //static String pars = "-u";


    @Override
    protected String doInBackground() throws Exception {
        final Vector<String> command = new Vector<String>();
        command.add(nusmvCommands);
        final StringTokenizer tokens = new StringTokenizer(
               nusmvParameters, " ");
       while (tokens.hasMoreTokens()) {
            command.add(tokens.nextToken());
        }

       // command.add(pars);
        command.add(modelFileSaved);
        final ProcessBuilder builder = new ProcessBuilder(command);
        builder.redirectErrorStream(true);
        final Process process = builder.start();
        final InputStream lsOut = process.getInputStream();
        final InputStreamReader r = new InputStreamReader(lsOut);
        final BufferedReader in = new BufferedReader(r);
        String line;
        while ((line = in.readLine()) != null) {
            modelOutput = String.valueOf(modelOutput) + line + "\n";
        }
        return modelOutput;
    }


    @Override
    protected void done() {

        String result = "";

        try {
            result = get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        super.done();

    }

    public static int numberOfOccurences(String text) {
        String find = new String(y);
        int index = 0, count = 0, length = find.length();
        while ((index = text.indexOf(find, index)) != -1) {
            index += length;
            count++;
        }
        return count;
    }


    public static String decodeBits(String modelOutput) {

        int test = modelOutput.indexOf(HashingData.decodeFromBits(s));// is false search
        if (test < 0) return modelOutput;
       // if (GlobalSystem.finished) return modelOutput;
        int index1 = modelOutput.indexOf(HashingData.decodeFromBits(y));// -- specification search
        if (index1 < 0) return modelOutput;


        int n = numberOfOccurences(modelOutput);// number of specifications total
        StringBuilder st = new StringBuilder(modelOutput);

        for (int i = 0; i < n; i++) {
            int verdict = st.indexOf(HashingData.decodeFromBits(mcmasWorker.i), index1);
            boolean f = false;
            int k = verdict + 3;
            while (st.charAt(verdict + 3) == ' ') {
                k++;
            }
            f = (st.charAt(k) == mcmasWorker.f);
            if (f) {

                int starting = verdict + 8;
                st.replace(verdict + 3, verdict + 8, HashingData.decodeFromBits(t));

                if (i == n - 1) {
                    int indexlast = st.indexOf(HashingData.decodeFromBits(h), verdict + 3);
                    if (indexlast != -1) {
                        st.replace(verdict + 7, indexlast, "");
                        st.insert(verdict + 7, "\n");
                    }
                } else {
                    index1 = st.indexOf(HashingData.decodeFromBits(e), verdict + 6);
                    System.out.println(index1);
                    st.replace(verdict + 7, index1 - 1, "");
                    st.insert(verdict + 7, "\n");
                    index1 = st.indexOf(HashingData.decodeFromBits(y), verdict + 6);
                }
            }else{
                index1 = st.indexOf(HashingData.decodeFromBits(y), k);
            }
        }
        return st.toString();
    }























// is false
    static char[] s = new char[]{105, 115, 32, 102, 97, 108, 115, 101};
    //--specification
    static char[] y = new char[]{45, 45, 32, 115, 112, 101, 99, 105, 102, 105, 99, 97, 116, 105, 111, 110, 32};
   // is
    static char[] i = new char[]{105, 115, 32};
    // evaluating specification
    static char[] e = new char[]{101, 118, 97, 108, 117, 97, 116, 105, 110, 103, 32, 115, 112, 101, 99, 105, 102, 105, 99, 97, 116, 105, 111, 110};
  // true 
    static char[] t = new char[]{116, 114, 117, 101};
    //###
    static char[] h = new char[]{35, 35, 35};
    //f
    static char f = 102;


}
