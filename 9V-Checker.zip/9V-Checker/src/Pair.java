import java.util.Objects;


public class Pair {
    String agent;
    String state;

    public Pair(String agent, String state) {
        this.agent = agent;
        this.state = state;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pair pair = (Pair) o;
        return agent.equals(pair.agent) &&
                state.equals(pair.state);
    }

    @Override
    public int hashCode() {
        return Objects.hash(agent, state);
    }

    @Override
    public String toString() {
        return agent+"."+state;
    }
}
