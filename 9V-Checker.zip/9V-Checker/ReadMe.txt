To run the tool:
1- Run the jar file named 9V-Checker.
2- Press the " Upload 9V-TCTL" button.
3- Press the corresponding buttons to transfer the uploaded file into 2V-TCTL files.
4- Press the "Launch MCMAS" button to obtain the verification results.
5- Apply the approximation rules as explained with Algorithm 1.  
 